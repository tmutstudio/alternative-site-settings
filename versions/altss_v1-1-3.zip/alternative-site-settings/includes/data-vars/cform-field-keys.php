<?php
$FORM_FIELD_KEYS = [
    'email',
    'phone',
    'fname',
    'sname',
    'city',
    'website',
    'message'
];
?>